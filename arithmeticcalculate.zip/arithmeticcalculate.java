package phase1;
import java.util.*;
public class arithmeticcalculate 
{
	public static void main(String[]args){
		
		try(Scanner sc = new Scanner(System.in))
		{
					System.out.println("Enter a number : ");
					double a=sc.nextDouble();
					int b=(int)a+22;
					
					System.out.println("Choose an Operation (+,-,*,/) : ");
					char ch = sc.next().charAt(0);
					operation(a,b,ch);
				}
				
			}
			public static void  operation(double a,int b,char ch) {
				double res = 0;
				switch(ch){
				// Addition
				case '+':
				{
		            res = a + b;
		            System.out.println(a + "+" + b + "="+res);
		            break;
		        }
		     // subtraction
				case '-':{
		            res = a - b;
		            System.out.println(a + "-" + b + "="+res);
		            break;
		        }
		     // multiplication
				case '*': {
		            res = a * b;
		            System.out.println(a + "*" + b + "="+res);
		            break;
		        }
		      // Division
				case '/': {
		            res = a / b;
		            System.out.println(a + "/" + b + "="+res);
		            break;
		        }
		       
			}
}
}
